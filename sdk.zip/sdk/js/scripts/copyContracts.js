const copydir = require("copy-dir");
copydir.sync("../../ethereum/build/contracts", "./contracts");
