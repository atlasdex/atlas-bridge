import * as wasm from "./nft_bridge_bg.wasm";
export * from "./nft_bridge_bg.js";