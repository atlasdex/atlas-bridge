import * as wasm from "./token_bridge_bg.wasm";
export * from "./token_bridge_bg.js";