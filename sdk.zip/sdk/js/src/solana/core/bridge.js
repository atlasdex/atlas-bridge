import * as wasm from "./bridge_bg.wasm";
export * from "./bridge_bg.js";