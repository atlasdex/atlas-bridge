import * as wasm from "./wormhole_migration_bg.wasm";
export * from "./wormhole_migration_bg.js";