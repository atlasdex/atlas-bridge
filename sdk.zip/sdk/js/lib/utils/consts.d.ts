export declare type ChainId = 1 | 2 | 3 | 4;
export declare const CHAIN_ID_SOLANA: ChainId;
export declare const CHAIN_ID_ETH: ChainId;
export declare const CHAIN_ID_TERRA: ChainId;
export declare const CHAIN_ID_BSC: ChainId;
