/// <reference types="node" />
export declare function createNonce(): Buffer;
