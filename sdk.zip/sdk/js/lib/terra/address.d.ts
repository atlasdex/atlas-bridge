export declare function canonicalAddress(humanAddress: string): Uint8Array;
export declare function humanAddress(canonicalAddress: Uint8Array): string;
