export default function poolAddress(program_id: string, from_mint: string, to_mint: string): Promise<Uint8Array>;
