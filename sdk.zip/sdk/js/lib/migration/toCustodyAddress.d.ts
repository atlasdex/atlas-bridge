export default function toCustodyAddress(program_id: string, pool: string): Promise<Uint8Array>;
