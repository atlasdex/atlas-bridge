export type { WormholeAbi } from "./WormholeAbi";
export { WormholeAbi__factory } from "./factories/WormholeAbi__factory";
