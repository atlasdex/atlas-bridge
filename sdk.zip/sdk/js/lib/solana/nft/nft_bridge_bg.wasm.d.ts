/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export function transfer_native_ix(a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number, j: number, k: number, l: number, m: number, n: number, o: number, p: number): number;
export function transfer_wrapped_ix(a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number, j: number, k: number, l: number, m: number, n: number, o: number, p: number, q: number, r: number, s: number, t: number, u: number): number;
export function complete_transfer_native_ix(a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number, j: number): number;
export function complete_transfer_wrapped_ix(a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number, j: number): number;
export function complete_transfer_wrapped_meta_ix(a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number): number;
export function upgrade_contract_ix(a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number, j: number): number;
export function register_chain_ix(a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number): number;
export function emitter_address(a: number, b: number, c: number): void;
export function approval_authority_address(a: number, b: number, c: number): void;
export function wrapped_address(a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number): void;
export function wrapped_meta_address(a: number, b: number, c: number, d: number, e: number): void;
export function spl_meta_address(a: number, b: number, c: number): void;
export function parse_wrapped_meta(a: number, b: number): number;
export function parse_endpoint_registration(a: number, b: number): number;
export function __wbindgen_malloc(a: number): number;
export function __wbindgen_realloc(a: number, b: number, c: number): number;
export function __wbindgen_add_to_stack_pointer(a: number): number;
export function __wbindgen_free(a: number, b: number): void;
