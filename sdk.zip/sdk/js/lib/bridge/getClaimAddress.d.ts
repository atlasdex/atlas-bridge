import { PublicKey } from "@solana/web3.js";
export declare function getClaimAddressSolana(programAddress: string, signedVAA: Uint8Array): Promise<PublicKey>;
