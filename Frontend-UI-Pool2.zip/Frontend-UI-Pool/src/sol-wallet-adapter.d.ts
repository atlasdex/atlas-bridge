declare module "@project-serum/sol-wallet-adapter" {
  const magic: any;
  export = magic;
}
